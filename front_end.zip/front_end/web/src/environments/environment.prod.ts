export const environment = {
  production: true,
  apiUrl: 'https://TON_API_PROD' 
};
