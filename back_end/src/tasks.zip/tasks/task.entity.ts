import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, Index } from 'typeorm';
import { User } from '../users/user.entity';
import { Aquarium } from '../aquariums/aquariums.entity';

export enum TaskStatus {
  PENDING = 'PENDING',
  DONE = 'DONE',
}

export enum TaskType {
  WATER_CHANGE = 'WATER_CHANGE',
  FERTILIZATION = 'FERTILIZATION',
  TRIM = 'TRIM',
  WATER_TEST = 'WATER_TEST',
  OTHER = 'OTHER',
}

@Entity('tasks')
export class Task {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 200 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  /** Date/heure de la tâche (UTC en DB) */
  @Index()
  @Column({ type: 'datetime' })
  dueAt: Date;

  /** Statut simple pour évoluer plus tard */
  @Column({ type: 'enum', enum: TaskStatus, default: TaskStatus.PENDING })
  status: TaskStatus;

  @CreateDateColumn()
  createdAt: Date;

  @ManyToOne(() => User, (u) => u.id, { onDelete: 'CASCADE', eager: false })
  user: User;

  @ManyToOne(() => Aquarium, (a) => a.id, { onDelete: 'CASCADE', eager: true })
  aquarium: Aquarium;

  @Column({ type: 'enum', enum: TaskType, default: TaskType.OTHER })
  type: TaskType;
}
